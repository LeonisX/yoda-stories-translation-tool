Thank you for downloading HTML Help DLL Registrar by Helpful Solutions.

This program is free and totally unsupported, though I may be induced to respond to kind questions and offers of pints of Guinness! :)

Please do *not* distribute this program or make it available for download from any websites without my express permission. Please *do* feel free to direct people to my site to download it though!

Paul A. O'Rear
Helpful Solutions
www.helpfulsolutions.com
pao@helpfulsolutions.com